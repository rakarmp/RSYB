#!/system/bin/sh
MODDIR=${0%/*}
/data/adb/modules/RSYB/RSYB

